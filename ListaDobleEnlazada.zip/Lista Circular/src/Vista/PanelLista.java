/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import Modelo.Nodo;
import java.awt.*;
import javax.swing.*;

/**
 *
 * @author asfak
 */
public class PanelLista extends JPanel {
    private Nodo cabeza = null;

    private static final int R = 28;
    private static final int ESPACIO_X = 90;
    private static final int CY = 80;
    public void actualizar(Nodo cabeza) {
        this.cabeza = cabeza;
        repaint();
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);
        if (cabeza == null) {
            g2.setColor(Color.GRAY);
            g2.setFont(new Font("Arial", Font.ITALIC, 14));
            g2.drawString("Lista vacía",
                    getWidth() / 2 - 160, CY);
            return;
        }
        int total = 0;
        Nodo tmp = cabeza;
        while (tmp != null) {
            total++;
            tmp = tmp.sig;
        }
        int anchoTotal = total * ESPACIO_X - (ESPACIO_X - 2 * R);
        int xInicio = Math.max(R + 10, (getWidth() - anchoTotal) / 2);

        Nodo curr = cabeza;
        int cx = xInicio + R;

        while (curr != null) {
            g2.setColor(new Color(173, 216, 230));
            g2.fillOval(cx - R, CY - R, 2 * R, 2 * R);
            g2.setColor(new Color(30, 100, 180));
            g2.setStroke(new BasicStroke(2));
            g2.drawOval(cx - R, CY - R, 2 * R, 2 * R);
            g2.setColor(Color.BLACK);
            g2.setFont(new Font("Monospaced", Font.BOLD, 11));
            FontMetrics fm = g2.getFontMetrics();
            int tw = fm.stringWidth(curr.num);
            g2.drawString(curr.num, cx - tw / 2, CY + fm.getAscent() / 2 - 1);
            if (curr.sig != null) {
                int xSig = cx + ESPACIO_X;
                dibujarFlecha(g2, cx + R, CY - 9, xSig - R, CY - 9,
                        new Color(30, 100, 180));
                dibujarFlecha(g2, xSig - R, CY + 9, cx + R, CY + 9,
                        new Color(200, 60, 30));
            }
            curr = curr.sig;
            cx += ESPACIO_X;
        }
    }

    private void dibujarFlecha(Graphics2D g2, int x1, int y1, int x2, int y2,
            Color color) {
        g2.setColor(color);
        g2.setStroke(new BasicStroke(1.8f));
        g2.drawLine(x1, y1, x2, y2);
        double angulo = Math.atan2(y2 - y1, x2 - x1);
        int largo = 8;
        double spread = Math.toRadians(28);
        int ax1 = (int) (x2 - largo * Math.cos(angulo - spread));
        int ay1 = (int) (y2 - largo * Math.sin(angulo - spread));
        int ax2 = (int) (x2 - largo * Math.cos(angulo + spread));
        int ay2 = (int) (y2 - largo * Math.sin(angulo + spread));
        g2.drawLine(x2, y2, ax1, ay1);
        g2.drawLine(x2, y2, ax2, ay2);
    }
}
