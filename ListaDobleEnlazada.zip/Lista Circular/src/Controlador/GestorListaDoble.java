/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Vista.PanelLista;
import Modelo.Nodo;
import java.util.Random;
import java.awt.*;
import javax.swing.*;
/**
 *
 * @author asfak
 */
public class GestorListaDoble extends JFrame {
 
    private Nodo cabeza = null;
    private Nodo cola   = null;
 
    private final PanelLista panelLista  = new PanelLista();
    private final JTextField campoRef    = new JTextField(6);
    private final JTextField campoVal    = new JTextField(6);
    private final JTextField campoPuente = new JTextField(6);
    private final JLabel     lblMensaje  = new JLabel(" ");
 
    public GestorListaDoble() {
        setTitle("Lista Doblemente Enlazada");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(8, 8));
 
        panelLista.setPreferredSize(new Dimension(800, 170));
        panelLista.setBorder(BorderFactory.createTitledBorder("Visualizacion de la lista"));
        panelLista.setBackground(Color.WHITE);
 
        JPanel controles = new JPanel();
        controles.setLayout(new BoxLayout(controles, BoxLayout.Y_AXIS));
        controles.setBorder(BorderFactory.createEmptyBorder(6, 8, 6, 8));
 
        JPanel filaGenerar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnGenerar = new JButton("Generar lista aleatoria");
        btnGenerar.addActionListener(e -> generarListaAleatoria());
        filaGenerar.add(btnGenerar);
 
        JPanel filaInsertar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filaInsertar.add(new JLabel("Insertar despues de:"));
        filaInsertar.add(campoRef);
        filaInsertar.add(new JLabel("  Valor nuevo:"));
        filaInsertar.add(campoVal);
        JButton btnInsertar = new JButton("Insertar nodo");
        btnInsertar.addActionListener(e -> insertarDespuesDe(
                campoRef.getText().trim(), campoVal.getText().trim()));
        filaInsertar.add(btnInsertar);
 
        JPanel filaPuente = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filaPuente.add(new JLabel("Puentear el nodo:"));
        filaPuente.add(campoPuente);
        JButton btnPuente = new JButton("Puentear nodo");
        btnPuente.addActionListener(e -> puentearNodo(campoPuente.getText().trim()));
        filaPuente.add(btnPuente);
 
        JPanel filaMensaje = new JPanel(new FlowLayout(FlowLayout.LEFT));
        lblMensaje.setFont(new Font("Arial", Font.ITALIC, 12));
        lblMensaje.setForeground(new Color(50, 50, 50));
        filaMensaje.add(lblMensaje);
 
        controles.add(filaGenerar);
        controles.add(filaInsertar);
        controles.add(filaPuente);
        controles.add(filaMensaje);
 
        add(panelLista, BorderLayout.CENTER);
        add(controles,  BorderLayout.SOUTH);
 
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
    private void generarListaAleatoria() {
        cabeza = null;
        cola   = null;
        Random rand = new Random();
        int num3 = rand.nextInt(8) + 3;
        for (int i = 0; i < num3; i++) {
            String num2 = Integer.toHexString(rand.nextInt(240) + 16).toUpperCase();
            Nodo q = new Nodo(num2);
 
            if (cabeza == null) {
                cabeza = q;
                cola   = q;
            } else {
                q.ant    = cola;
                cola.sig = q;
                cola     = q;
            }
        }
 
        mensaje("Lista generada con " + num3 + " nodos");
        refrescar();
    }
     private void insertarDespuesDe(String referencia, String valor) {
        if (cabeza == null)                          { mensaje("Lista vacia"); return; }
        if (referencia.isEmpty() || valor.isEmpty()) { mensaje("Rellena ambos cuadros"); return; }
 
        referencia = referencia.toUpperCase();
        valor      = valor.toUpperCase();
 
        Nodo aux = cabeza;
        while (aux != null && !aux.num.equals(referencia)) aux = aux.sig;
 
        if (aux == null) { mensaje("El nodo '" + referencia + "' no existe"); return; }
 
        Nodo nuevo = new Nodo(valor);
 
        if (aux.sig == null) {        
            nuevo.ant = aux;
            aux.sig   = nuevo;
            cola      = nuevo;
        } else {                       
            Nodo sig  = aux.sig;
            nuevo.ant = aux;
            nuevo.sig = sig;
            aux.sig   = nuevo;
            sig.ant   = nuevo;
        }
 
        mensaje("" + valor + "' insertado despues de '" + referencia + "'");
        campoRef.setText("");
        campoVal.setText("");
        refrescar();
    }
     
    private void puentearNodo(String target) {
        if (cabeza == null)   { mensaje("Lista vacia"); return; }
        if (target.isEmpty()) { mensaje("Ingrese un valor"); return; }
 
        target = target.toUpperCase();
 
        Nodo aux = cabeza;
        while (aux != null && !aux.num.equals(target)) aux = aux.sig;
 
        if (aux == null) { mensaje("El nodo '" + target + "' no existe"); return; }
 
        if (aux.ant != null) aux.ant.sig = aux.sig;  else cabeza = aux.sig;
        if (aux.sig != null) aux.sig.ant = aux.ant;  else cola   = aux.ant;
 
        mensaje("Nodo '" + target + "' eliminado exitosamente");
        campoPuente.setText("");
        refrescar();
    }
    private void refrescar() { panelLista.actualizar(cabeza); }
    private void mensaje(String texto) { lblMensaje.setText(texto); }
    
}
