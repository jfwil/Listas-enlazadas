/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Modelo;

import java.util.Random;
import java.util.Scanner;
import java.awt.*;
import javax.swing.*;

import Controlador.GestorListaDoble;

/**
 *
 * @author asfak
 */
public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(GestorListaDoble::new);
    }
}
