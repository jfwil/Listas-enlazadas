/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author asfak
 */
public class Nodo {
    
    public String num;
    public Nodo sig;
    public Nodo ant; 
 
    public Nodo(String dato) {
        this.num = dato;
        this.sig = null;
        this.ant = null;
    }
}
